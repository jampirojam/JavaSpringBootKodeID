=======================================================
Nama: 
-- M. Machrush Aliy Sirojjam Mushlich
Kode Peserta: 
-- JVSB001ONL006
Link GitHub: 
-- https://github.com/jampirojam
=======================================================

PANDUAN PENGGUNAAN APLIKASI

Latihan_1

- input r
- jika r % 7 == 0 maka phi = 22/7, jika tidak maka phi = 3.14
- menghitung luas menggunakan rumus luas = phi * r * r
- output luas
____________

Latihan_2

Setelah dilakukan analisis berdasarkan kode yang disediakan, hasil sesuai dengan yang diinginkan, sehingga tidak perlu adanya modifikasi
____________

Latihan_3

Setelah dilakukan pembuatan secara keseluruhan, dan penggunaan I/D tidak berubah dengan hasil yang diinginkan, maka penulisan kodenya dipersingkat dengan menggunakan perulangan for
___________

Latihan_4

Semua kondisi yang menghasilkan keluaran yang diinginkan sudah ditulis berdasarkan nilai inputan
___________

Latihan_5

Semua kode berjalan sudah selesai, tetapi untuk dapat menghasilkan kondisi
- true >>> X1 == X2
- false >>> X2 == X1
- true >>> (X1 % 4) == (X2 % 5)
terpenuhi semuanya, maka nilai masukan harus 0.